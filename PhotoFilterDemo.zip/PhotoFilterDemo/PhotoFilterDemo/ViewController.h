//
//  ViewController.h
//  PhotoFilterDemo
//
//  Created by Mark Hammonds on 9/3/12.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIActionSheetDelegate>

@end
