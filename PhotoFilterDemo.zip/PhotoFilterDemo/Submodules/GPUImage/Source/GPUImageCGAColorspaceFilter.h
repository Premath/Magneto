#import "GPUImageFilter.h"

@interface GPUImageCGAColorspaceFilter : GPUImageFilter

@end
