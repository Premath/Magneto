#import "GPUImage3x3TextureSamplingFilter.h"

@interface GPUImageWeakPixelInclusionFilter : GPUImage3x3TextureSamplingFilter

@end
